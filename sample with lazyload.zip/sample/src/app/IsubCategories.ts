export interface ISubCategories {
    id: string;
    title: string;
}