export interface ILogin {    
    countryId: string;
    username: string;
    password: string;
    expiresInMinute: number;
}