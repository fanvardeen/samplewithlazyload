import { Component, OnInit } from '@angular/core';
import { CategoryService } from './category.service';
import { ICategory } from './ICategory';
import { toArray } from 'rxjs/operators';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  category: any;
  panelexpanded = true;

  constructor(private _categoryService: CategoryService) { }

  ngOnInit(): void {
    this._categoryService.getCategory().subscribe((res: any) => {
      this.category = res.result;
      console.log(this.category);
    });

  }


}
