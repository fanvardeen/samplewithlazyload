import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { ICategory } from './ICategory';
import { ICountry } from './ICountry';
import { ILogin } from './ILogin';

@Injectable()
export class CategoryService {
    //baseUrl = 'http://208.109.13.111:9090/api/Category';
    baseUrl = '/assets/Category.json.txt';
    loginUrl = 'http://208.109.13.111:9191/api/Account/Login';
    countryUrl = 'http://208.109.13.111:9191/api/Country';

    constructor(private httpClient: HttpClient) {
    }

    getCategory(): Observable<ICategory[]> {
        return this.httpClient.get<ICategory[]>(this.baseUrl)
            .pipe(
                catchError(this.handleError));
    }


    getCountry(): Observable<ICountry[]> {
        return this.httpClient.get<ICountry[]>(this.countryUrl)
            .pipe(catchError(this.handleError));
    }

    private handleError(errorResponse: HttpErrorResponse) {
        if (errorResponse.error instanceof ErrorEvent) {
            console.error('Client Side Error :', errorResponse.error.message);
        } else {
            console.error('Server Side Error :', errorResponse);
        }
        return throwError('There is a problem with the service. We are notified & working on it. Please try again later.');
    }


    addLogin(login: ILogin): Observable<ILogin> {
        return this.httpClient.post<ILogin>(this.loginUrl, login, {
            headers: new HttpHeaders({
                'Content-Type': 'application/json'
            })
        })
            .pipe(catchError(this.handleError));
    }



}